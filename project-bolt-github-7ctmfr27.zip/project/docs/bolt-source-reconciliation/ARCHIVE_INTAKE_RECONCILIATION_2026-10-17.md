# ملحق جرد — أرشيفات استعادة Bolt الجديدة (18 أكتوبر 2026)

المعلومات التالية metadata في GitHub فقط؛ لا تدّعي تنزيل البايتات أو فك ZIP.

| الاسم | الحجم | Git blob SHA-1 | SHA-256 | حالة التنزيل/الاستخراج |
|---|---:|---|---|---|
| Nasr1_Bolt_Before_Failure.zip | 1,003,172 | 7c35f3ecde19dc5596fd22053be61924ef3d5318 | NOT RUN | bytes / SHA-256 / ZIP integrity / extraction = NOT RUN |
| Nasr1_Bolt_Restored_Current.zip | 997,589 | f01684a56e093a33a173b0965d1d7239c48f0936 | NOT RUN | bytes / SHA-256 / ZIP integrity / extraction = NOT RUN |

المصدر: https://github.com/Report-Engainall/report-insight-engine/tree/main/incoming-archives/nasr1-bolt-recovery-2026-10-17. Git blob SHA-1 ليس SHA-256 للأرشيف. لا توجد أعضاء مستخرجة موثقة في ARCHIVE_MEMBERS.csv.

---

# تدقيق مدخلات أرشيفات متجر الأغبري — 17 أكتوبر 2026

## 1. نطاق التحقق وحدوده

- المشروع المستهدف: https://github.com/Report-Engainall/Nasr1
- مستودع استقبال الأرشيفات: https://github.com/Report-Engainall/report-insight-engine
- مجلد الإدخال: https://github.com/Report-Engainall/report-insight-engine/tree/main/incoming-archives/commerce-source-reconciliation
- عدد ملفات الأرشيف التي ظهرت في القائمة الحية: **12**.
- مجموع أحجامها: **90,825,000 بايت**.
- التوزيع: **7 ملفات ZIP و5 ملفات RAR**؛ من ضمنها جزآن يحملان الاسمين SOURCE12.part1.rar وSOURCE12.part2.rar.
- هذا إثبات لجرد الملفات وأحجامها وGit blob SHA في GitHub. ليس دليلًا على أن الأرشيفات الاثني عشر فُكّت أو أن ملفاتها المصدرية اختُبرت.

## 2. الأرشيفات الموجودة فعليًا

Git blob SHA هو معرّف كائن Git مبني على SHA-1، وليس SHA-256 لمحتوى الأرشيف. حسبت SHA-256 من البايتات الفعلية فقط للأربعة ملفات التي أمكن الحصول على بايتاتها من استجابة Base64. لم أضع بصمة مخمّنة لبقية الملفات.

| الاسم | الحجم بالبايت | Git blob SHA | SHA-256 لمحتوى الأرشيف | النتيجة |
|---|---:|---|---|---|
| AGHBARI_COMMERCE_UNIFIED_SOURCE_PACKAGE (1).zip | 34,644 | 0cc62627603575cb5e071e5c2fa5aee116333122 | b5c70093fe28e46b3ebee8394c7bd6bdddf5aef33eb95331e086de4db0790323 | فهرس ZIP مقروء؛ 19 مدخلًا. حزمة جرد ووثائق لا شجرة كود كاملة |
| SOURCE.1.zip | 659,479 | 26fe0f124bf39fd4cebb350435f2691280ace5e9 | 7c91def7f2e4ca597f82239e5815626f178f1eb02def4c0ff4bd2cd043d605f6 | فهرس ZIP مقروء؛ فك المحتوى واختبار CRC الكامل لم يثبتا |
| SOURCE2.zip | 1,988,698 | c309ddf72e1fd32d79239b0bd721c17691142435 | غير محسوب | الاسم والحجم وGit blob متاح؛ بايتات ZIP لم تُسترجع في هذه البيئة |
| SOURCE3.zip | 659,479 | 3793f0548ee949eeddec290f135a1317a7a0fd6e | 8bc65a6ee0fd1cdb9fb185d6f361ef5fbf2ea9e0d1d59a663c98b3c6aff23e56 | فهرس ZIP مقروء؛ مرشح تكرار قوي |
| SOURCE4.zip | 11,067,400 | 16475379e302b3d5027292bf0560acb7d08b03ea | غير محسوب | الاسم والحجم وGit blob متاح؛ بايتات ZIP لم تُسترجع في هذه البيئة |
| SOURCE5.zip | 659,479 | 6ae1fa5577ba27cecb4eb82ddd09deff1f1be35d | 9a05e24a796a7f5a9d715b44978029cdb5ef79b16fb0c86fd4e8d6b4c394d18f | فهرس ZIP مقروء؛ مرشح تكرار قوي |
| SOURCE6.zip | 4,254,370 | 97a9955985d0af34764a5793b54581b38110faca | غير محسوب | الاسم والحجم وGit blob متاح؛ بايتات ZIP لم تُسترجع في هذه البيئة |
| SOURCE7.rar | 2,235,331 | 738b5f9623f3b2456822b2cb9b7ca10b3bb7e5fd | غير محسوب | لم يتم تنزيل البايتات وفك الأرشيف |
| SOURCE10.rar | 20,971,520 | 032bac82b4ebf1ddde6a280980f2b0954341e676 | غير محسوب | لم يتم تنزيل البايتات وفك الأرشيف |
| SOURCE11.rar | 12,742,835 | 49645811eac17904e342a3de213f83c264b70772 | غير محسوب | لم يتم تنزيل البايتات وفك الأرشيف |
| SOURCE12.part1.rar | 24,117,248 | 32c5a75b2c437cc71b808fe6647897de15430a4c | غير محسوب | الجزء الأول؛ يجب فحصه مع الجزء الثاني إن كانا أرشيفًا متعدد الأجزاء |
| SOURCE12.part2.rar | 11,434,517 | 69246c2ad578e6217e756c2658c01a232c9fb47e | غير محسوب | الجزء الثاني؛ لا يُعامل كأرشيف مستقل قبل التأكد من التنسيق |

روابط الوصول:
- مجلد الاستقبال: https://github.com/Report-Engainall/report-insight-engine/tree/main/incoming-archives/commerce-source-reconciliation
- سجل جرد الملفات السابق: https://github.com/Report-Engainall/report-insight-engine/tree/main/incoming-archives/commerce-source-reconciliation/01_SOURCE_INVENTORY
- سكربت التجميع الحالي: https://github.com/Report-Engainall/report-insight-engine/blob/main/incoming-archives/commerce-source-reconciliation/tools/build_source_package.py
- سير العمل الحالي: https://github.com/Report-Engainall/report-insight-engine/blob/main/.github/workflows/commerce-source-reconciliation.yml

## 3. نتائج فهرس ZIP الأولية

### ملف الحزمة الصغيرة

الملف AGHBARI_COMMERCE_UNIFIED_SOURCE_PACKAGE (1).zip يحتوي على 19 مدخلًا في فهرس ZIP وحجم إجمالي غير مضغوط مسجل قدره 72,166 بايت. يتضمن README والجرد وبصمات ملفات وسجل مصادر ومواصفات وتعارضات. يحتوي على المسار 02_CANONICAL_PROJECT/NOT_MATERIALIZED.txt الذي يوضح أن شجرة التطبيق لم تُضمّن. بصمة SHA-256 المحسوبة تطابق القيمة الموثقة سابقًا: b5c70093fe28e46b3ebee8394c7bd6bdddf5aef33eb95331e086de4db0790323.

إذن هذا الملف **ليس** بديلًا مثبتًا للأرشيف الأصلي الذي أُبلغ أن حجمه 95,377,100 بايت.

### الملفات SOURCE.1.zip وSOURCE3.zip وSOURCE5.zip

تمت قراءة فهرس ZIP لكل ملف عبر البايتات المستلمة. لكل واحد:
- 282 مدخلًا في الفهرس، تشمل مجلدات.
- حجم غير مضغوط مسجل 2,256,950 بايت.
- جذع مشروع ظاهر باسم project/.
- مسارات وأحجام وCRC-32 مطابقة بين المدخلات المقابلة في الفهارس الثلاثة.

لكن SHA-256 للأرشيفات نفسها مختلف. النتيجة الدقيقة: **مرشحات تكرار قوية على مستوى محتويات الملفات المفهرسة**، وليست أرشيفات متطابقة بايتًا ببايت. يلزم الفك إلى مجلدات معزولة ثم حساب SHA-256 لكل عضو قبل تقرير أن الملفات الداخلية متطابقة.

أسماء المسارات المفهرسة تشمل:
- project/src/ ومكونات وصفحات الواجهة.
- project/drizzle/migrations/ وملفات SQL.
- project/supabase/migrations/.
- project/supabase/functions/ai-gateway/.
- project/supabase/functions/outbox-worker/.
- project/.github/workflows/commerce-checks.yml.
- ملفات الحزم والإعدادات وREADME وAGENTS.md وPROJECT_MEMORY.md.

الأعداد المستخرجة من فهرس الملفات لهذه النسخ: 123 ملف TSX، و48 ملف TS، و40 ملف SQL، و14 ملف Markdown، و8 ملفات JSON، وملفا JS وثلاثة ملفات CSS. هذه **أعداد فهرسية وليست تأكيدًا على البناء أو الاختبارات**.

### تنبيه أمني

يظهر الاسم project/.env في فهرس الأرشيفات الثلاثة. لم تُقرأ قيمه، ولم تُطبع أو تُنشر أي أسرار. يجب فحص الملف داخل بيئة آمنة فقط، وعدم نسخه إلى حزمة عامة؛ استبعده أو نقّح الأسرار ومفاتيح API وكلمات المرور والبيانات الشخصية. لا تشغّل أي كود مستخرج خلال مرحلة الجرد.

## 4. سبب عدم اعتبار الفحص شاملًا بعد

1. سكربت build_source_package.py يقرأ ملفات ZIP فقط باستخدام zipfile؛ لا يدعم استخراج RAR.
2. سير العمل .github/workflows/commerce-source-reconciliation.yml يراقب حاليًا تغييرات ZIP ومسارات السكربت، ولا يفعّل الجمع عند كل ملفات RAR الظاهرة.
3. ملفات external_archive_inventory.csv وpackage-result.json الموجودة في 01_SOURCE_INVENTORY تعكس تشغيلًا سابقًا لم يرَ سوى ZIP واحد. لا تمثل حالة الملفات الاثني عشر الحالية.
4. بوابة الجاهزية في السكربت تعتمد على وجود ZIP عددها اثنان أو أكثر؛ وهذا لا يثبت أن ZIP يضم المشروعين المطلوبين أو أن RAR المشاريع السبعة تم استخراجه.
5. استجابة موصل GitHub النصية تعذرت في استرجاع بايتات SOURCE2.zip وSOURCE4.zip وSOURCE6.zip بسبب كونها بيانات ثنائية، وفشلت محاولة الوصول الخام في بيئة التنفيذ الحالية. لا يعني ذلك أنها غير موجودة.
6. لم يتم اختبار أو استخراج ملفات SOURCE7.rar وSOURCE10.rar وSOURCE11.rar وأجزاء SOURCE12.rar في هذه الجلسة.

## 5. الأرشيفات السابقة التي يجب البحث عنها دون طلب إعادة رفع عشوائي

- الأرشيف الأصلي AGHBARI_COMMERCE_UNIFIED_SOURCE_PACKAGE.zip، بحجم مُبلغ عنه 95,377,100 بايت: لم تتم مطابقة أي ملف حالي معه.
- أرشيف المشاريع السبعة في https://github.com/adnanabderab2016-sys/-7-/ — اسم الملف: «استخرج من كل المشاريع ما ينتج مشروع مكتمل للمتجر الالكتروني .rar»، الحجم المسجل 25,811,682 بايت، Git blob SHA: dd96610641b7f0a7af765b72d406b1553f67f89e. بايتاته وSHA-256 واختبار سلامته واستخراجه لا تزال غير مثبتة.
- الأرشيف الإضافي متعدد المشاريع: ابحث عن روابطه وأصول Releases الحالية قبل طلب أي رفع جديد.
- لا تفترض أن SOURCE.1.zip يطابق SOURCE1.zip، ولا تفترض أن اللقطات السابقة أو الحجم المشابه بدائل مطابقة للأرشيف الأصلي.

## 6. المهمة المطلوبة من Bolt أو بيئة تشغيل مناسبة

1. استخدم نسخة عمل مؤقتة أو GitHub Actions/runner لديه تنزيل بايتات GitHub الخام. نزّل الأرشيفات بأسمائها ومساراتها الأصلية؛ احسب SHA-256 الحقيقي لكل ملف.
2. افحص ZIP باختبار CRC، واستعمل أداة RAR5 حديثة مثل 7zz أو unar لقائمة المحتويات واختبار سلامة RAR وفكّه. اختبر SOURCE12.part1.rar مع SOURCE12.part2.rar كمجموعة واحدة إن أكد تنسيق الأرشيف ذلك.
3. ضع كل أرشيف في مجلد استخراج مستقل. حدّد حدودًا للأعضاء وحجم فك الضغط وعمق الأرشيف، وامنع المسارات المطلقة و.. والروابط الخطرة وzip bombs. لا تنفذ scripts أو migrations أو ملفات تنفيذية مستخرجة.
4. احفظ ARCHIVE_MANIFEST.csv وARCHIVE_MEMBERS.csv مع اسم الأرشيف والمسار والحجم وSHA-256 والنوع وحالة الإدراج أو الاستبعاد وسببها. أضف PROJECT_ROOTS.md لتسمية المشاريع كما ظهرت فعليًا داخل الأرشيف.
5. قارن SHA-256 لأعضاء الملفات بعد الفك، ثم قارن المشاريع مع Nasr1 وREADY_TO_REUSE/PROVENANCE_MANIFEST.csv. سجّل الاختلافات بدل الحذف أو الاستبدال.
6. صنّف كل ملف: مطابق، نسخة أحدث، أكثر اكتمالًا، فرق مفيد، يحتاج تكييفًا، حساس/مستبعد، غير متوافق، أو لم يُفحص.
7. وثّق INTEGRATION_DECISIONS.md وSOURCE_DIFFS.md وDEPENDENCY_SECURITY_REVIEW.md؛ اربط كل قرار بالمصدر والمسار والبصمة والتبعية والاختبار.
8. حدّث missing_inputs.csv وexternal_archive_inventory.csv وexternal_archive_members.csv وpackage-result.json بعد استكمال الفحص، وليس قبله.
9. لا تعلن أن الأرشيفات فُحصت أو المشاريع السبعة استُخرجت حتى تسلّم أدلة البايتات والفك والجرد الفعلي. إذا تعذر مصدر بعينه، سجّله BLOCKED وواصل العمل على المصادر المتاحة.

## 7. الحالة النهائية لهذه اللقطة

- **تم التحقق:** ظهور 12 ملف أرشيف في قائمة المستودع، أسماؤها وأحجامها ومعرفات Git blob.
- **تم التحقق جزئيًا:** بايتات أربعة ZIPs أمكن قراءتها وفحص فهارسها؛ SHA-256 محسوب فعليًا لهذه الملفات الأربعة. كما تم إثبات تشابه فهرسة الملفات في ثلاثة ZIPs.
- **لم يتم:** استخراج شامل لجميع الأرشيفات، تحديد كل جذور المشاريع السبعة بالبايتات الأصلية، فحص ملفات المصدر كلها، مقارنة كل الملفات ببصمة، تشغيل الاختبارات، أو دمج ملفات في تطبيق Nasr1.
- **قرار آمن:** لا يُحذف أو يُستبدل أي مصدر، ولا تعلن PASS نهائي، قبل إثبات الملف الفعلي والاختبارات ذات الصلة.

